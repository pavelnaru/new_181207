import { IEmployee } from 'app/shared/model//employee.model';
import { ILocation } from 'app/shared/model//location.model';

export interface IDepartment {
    id?: number;
    departmentName?: string;
    employees?: IEmployee[];
    location?: ILocation;
}

export class Department implements IDepartment {
    constructor(public id?: number, public departmentName?: string, public employees?: IEmployee[], public location?: ILocation) {}
}
