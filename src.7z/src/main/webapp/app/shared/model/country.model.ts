import { IRegion } from 'app/shared/model//region.model';
import { ILocation } from 'app/shared/model//location.model';

export interface ICountry {
    id?: number;
    countryName?: string;
    region?: IRegion;
    locations?: ILocation[];
}

export class Country implements ICountry {
    constructor(public id?: number, public countryName?: string, public region?: IRegion, public locations?: ILocation[]) {}
}
