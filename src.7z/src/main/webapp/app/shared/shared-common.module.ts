import { NgModule } from '@angular/core';

import { New181207SharedLibsModule, JhiAlertComponent, JhiAlertErrorComponent } from './';

@NgModule({
    imports: [New181207SharedLibsModule],
    declarations: [JhiAlertComponent, JhiAlertErrorComponent],
    exports: [New181207SharedLibsModule, JhiAlertComponent, JhiAlertErrorComponent]
})
export class New181207SharedCommonModule {}
