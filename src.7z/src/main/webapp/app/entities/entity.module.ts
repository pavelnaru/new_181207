import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { New181207RegionModule } from './region/region.module';
import { New181207CountryModule } from './country/country.module';
import { New181207LocationModule } from './location/location.module';
import { New181207DepartmentModule } from './department/department.module';
import { New181207TaskModule } from './task/task.module';
import { New181207EmployeeModule } from './employee/employee.module';
import { New181207JobModule } from './job/job.module';
import { New181207JobHistoryModule } from './job-history/job-history.module';
/* jhipster-needle-add-entity-module-import - JHipster will add entity modules imports here */

@NgModule({
    // prettier-ignore
    imports: [
        New181207RegionModule,
        New181207CountryModule,
        New181207LocationModule,
        New181207DepartmentModule,
        New181207TaskModule,
        New181207EmployeeModule,
        New181207JobModule,
        New181207JobHistoryModule,
        /* jhipster-needle-add-entity-module - JHipster will add entity modules here */
    ],
    declarations: [],
    entryComponents: [],
    providers: [],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class New181207EntityModule {}
