export * from './task.service';
export * from './task-update.component';
export * from './task-delete-dialog.component';
export * from './task-detail.component';
export * from './task.component';
export * from './task.route';
