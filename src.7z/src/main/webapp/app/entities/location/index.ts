export * from './location.service';
export * from './location-update.component';
export * from './location-delete-dialog.component';
export * from './location-detail.component';
export * from './location.component';
export * from './location.route';
