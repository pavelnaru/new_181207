package thientoan.learning.web.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Test1Resource controller
 */
@RestController
@RequestMapping("/api/test-1")
public class Test1Resource {

    private final Logger log = LoggerFactory.getLogger(Test1Resource.class);

    /**
    * GET test1_get1
    */
    @GetMapping("/test-1-get-1")
    public String test1_get1() {
        return "test1_get1";
    }

}
