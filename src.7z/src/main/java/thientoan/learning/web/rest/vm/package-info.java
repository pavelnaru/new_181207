/**
 * View Models used by Spring MVC REST controllers.
 */
package thientoan.learning.web.rest.vm;
