package thientoan.learning.service;

public interface DemoService1Service {

}
