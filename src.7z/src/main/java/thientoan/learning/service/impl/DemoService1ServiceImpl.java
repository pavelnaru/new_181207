package thientoan.learning.service.impl;

import thientoan.learning.service.DemoService1Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class DemoService1ServiceImpl implements DemoService1Service {

    private final Logger log = LoggerFactory.getLogger(DemoService1ServiceImpl.class);

}
