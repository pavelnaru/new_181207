/**
 * Service layer beans.
 */
package thientoan.learning.service;
