package thientoan.learning.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Properties specific to New 181207.
 * <p>
 * Properties are configured in the application.yml file.
 * See {@link io.github.jhipster.config.JHipsterProperties} for a good example.
 */
@ConfigurationProperties(prefix = "application", ignoreUnknownFields = false)
public class ApplicationProperties {

}
