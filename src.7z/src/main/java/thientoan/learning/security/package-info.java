/**
 * Spring Security configuration.
 */
package thientoan.learning.security;
