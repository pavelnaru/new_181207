/**
 * Spring Data JPA repositories.
 */
package thientoan.learning.repository;
