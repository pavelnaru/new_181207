/**
 * JPA domain objects.
 */
package thientoan.learning.domain;
